# Setting Attributes

In this activity you are going to use JavaScript to add `hrefs` to `a` tags, `src` to `img` tags, along with some styles all while traversing the DOM.

## Instructions

* Open `index.html` and familiarize yourself with the structure of the HTML.

* Inside of your provided `script.js` complete the following: 

  * Give a `src` and `alt` attribute to the 3 provided `img` tags.

  * Give a `href` attribute to the 3 provided `a` tags.`

  * Add styles via `setAttribute` to make the page look decent. Recommended: margins and padding.

## Hint 

* You may need a for loop!

## Bonus
 
* Randomly set the `href` for site 1 from an array of sites you create.



